﻿/* ============================================================
   PKS FOUNDATION
   PUBLIC STUDENT REVIEWS
   FINAL SUMMARY FIX
============================================================ */

(function () {

    "use strict";


    /* ========================================================
       ESCAPE HTML
    ======================================================== */

    function escapeHTML(value) {

        return String(value ?? "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");

    }


    /* ========================================================
       CREATE STAR DISPLAY
    ======================================================== */

    function createStars(rating) {

        const number =
            Math.max(
                0,
                Math.min(
                    5,
                    Number(rating) || 0
                )
            );

        let stars = "";

        for (
            let i = 1;
            i <= 5;
            i++
        ) {

            stars +=
                i <= number
                    ? "★"
                    : "☆";

        }

        return stars;

    }


    /* ========================================================
       FORMAT DATE
    ======================================================== */

    function formatDate(dateValue) {

        if (!dateValue) {
            return "";
        }

        const date =
            new Date(dateValue);

        if (
            Number.isNaN(
                date.getTime()
            )
        ) {

            return "";

        }

        return date.toLocaleDateString(
            "en-IN",
            {
                day: "numeric",
                month: "short",
                year: "numeric"
            }
        );

    }


    /* ========================================================
       CREATE REVIEW CARD
    ======================================================== */

    function createReviewCard(review) {

        const studentName =
            escapeHTML(
                review.studentName ||
                "PKS Student"
            );


        const reviewText =
            escapeHTML(
                review.reviewText ||
                ""
            );


        const rating =
            Number(
                review.rating
            ) || 0;


        const date =
            formatDate(
                review.createdAt
            );


        const initials =
            String(
                review.studentName ||
                "P"
            )
                .trim()
                .split(/\s+/)
                .map(
                    word =>
                        word.charAt(0)
                )
                .join("")
                .substring(0, 2)
                .toUpperCase();


        return `

            <article class="public-review-card">

                <div class="public-review-top">

                    <div class="public-review-avatar">
                        ${escapeHTML(initials)}
                    </div>


                    <div class="public-review-person">

                        <h3>
                            ${studentName}
                        </h3>

                        ${
                            date
                                ? `
                                    <span>
                                        ${date}
                                    </span>
                                  `
                                : ""
                        }

                    </div>

                </div>


                <div
                    class="public-review-stars"
                    aria-label="${rating} out of 5 stars"
                >
                    ${createStars(rating)}
                </div>


                ${
                    reviewText
                        ? `
                            <p class="public-review-text">
                                “${reviewText}”
                            </p>
                          `
                        : `
                            <p class="public-review-text">
                                ⭐ Thank you for your valuable feedback.
                            </p>
                          `
                }

            </article>

        `;

    }


    /* ========================================================
       RENDER REVIEWS
    ======================================================== */

    function renderReviews(data) {

        const container =
            document.getElementById(
                "publicReviewsGrid"
            );


        const emptyState =
            document.getElementById(
                "publicReviewsEmpty"
            );


        const averageElement =
            document.getElementById(
                "publicReviewsAverage"
            );


        const totalElement =
            document.getElementById(
                "publicReviewsTotal"
            );


        if (!container) {

            console.warn(
                "PKS Reviews: review container not found."
            );

            return;

        }


        /*
         * IMPORTANT:
         *
         * The PKS backend returns:
         *
         * {
         *   success: true,
         *   reviews: [...],
         *   averageRating: 5,
         *   totalRatings: 1
         * }
         *
         * NOT:
         *
         * summary: {
         *   averageRating: 5,
         *   totalRatings: 1
         * }
         *
         * Therefore we read the values directly.
         */


        const averageRating =
            Number(
                data?.averageRating ?? 0
            );


        const totalRatings =
            Number(
                data?.totalRatings ?? 0
            );


        /* ====================================================
           UPDATE AVERAGE RATING
        ==================================================== */

        if (averageElement) {

            averageElement.textContent =
                averageRating.toFixed(1);

        }


        /* ====================================================
           UPDATE TOTAL REVIEWS
        ==================================================== */

        if (totalElement) {

            totalElement.textContent =
                String(totalRatings);

        }


        /* ====================================================
           GET REVIEWS
        ==================================================== */

        const reviews =
            Array.isArray(
                data?.reviews
            )
                ? data.reviews
                : [];


        /* ====================================================
           NO REVIEWS
        ==================================================== */

        if (!reviews.length) {

            container.innerHTML = "";

            if (emptyState) {

                emptyState.hidden =
                    false;

            }

            return;

        }


        /* ====================================================
           REVIEWS FOUND
        ==================================================== */

        if (emptyState) {

            emptyState.hidden =
                true;

        }


        container.innerHTML =
            reviews
                .map(
                    createReviewCard
                )
                .join("");

    }


    /* ========================================================
       LOAD PUBLIC REVIEWS
    ======================================================== */

    async function loadPublicReviews() {

        const container =
            document.getElementById(
                "publicReviewsGrid"
            );


        if (!container) {

            return;

        }


        try {

            const response =
                await fetch(
                    "/api/reviews",
                    {
                        method: "GET",

                        headers: {
                            "Accept":
                                "application/json"
                        },

                        cache:
                            "no-store"
                    }
                );


            if (!response.ok) {

                throw new Error(
                    "Unable to load reviews."
                );

            }


            const data =
                await response.json();


            if (
                !data ||
                data.success !== true
            ) {

                throw new Error(
                    data?.message ||
                    "Unable to load reviews."
                );

            }


            console.log(
                "PKS Public Reviews:",
                data
            );


            renderReviews(
                data
            );


        } catch (error) {

            console.error(
                "PKS Public Reviews Error:",
                error
            );


            const emptyState =
                document.getElementById(
                    "publicReviewsEmpty"
                );


            if (emptyState) {

                emptyState.hidden =
                    false;

                emptyState.innerHTML = `

                    <div class="public-reviews-empty-icon">
                        ⭐
                    </div>

                    <h3>
                        Student Reviews
                    </h3>

                    <p>
                        Reviews from our learners will appear here.
                    </p>

                `;

            }

        }

    }


    /* ========================================================
       START
    ======================================================== */

    document.addEventListener(
        "DOMContentLoaded",
        function () {

            loadPublicReviews();

        }
    );


})();
