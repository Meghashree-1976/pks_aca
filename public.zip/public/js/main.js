/* =========================================================
   PKS FOUNDATION
   PUBLIC WEBSITE — MAIN JAVASCRIPT
========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    /* =====================================================
       ELEMENTS
    ===================================================== */

    const menuButton = document.getElementById("menuButton");
    const closeMenu = document.getElementById("closeMenu");
    const sideMenu = document.getElementById("sideMenu");
    const menuOverlay = document.getElementById("menuOverlay");
    const currentYear = document.getElementById("currentYear");


    /* =====================================================
       YEAR
    ===================================================== */

    if (currentYear) {
        currentYear.textContent = new Date().getFullYear();
    }


    /* =====================================================
       MENU STATE
    ===================================================== */

    function openMenu() {

        if (!sideMenu || !menuOverlay) {
            return;
        }

        sideMenu.hidden = false;
        menuOverlay.hidden = false;

        requestAnimationFrame(() => {

            sideMenu.classList.add("open");
            menuOverlay.classList.add("open");

        });

        sideMenu.setAttribute("aria-hidden", "false");
        menuOverlay.setAttribute("aria-hidden", "false");

        if (menuButton) {
            menuButton.setAttribute(
                "aria-expanded",
                "true"
            );

            menuButton.setAttribute(
                "aria-label",
                "Close navigation menu"
            );
        }

        document.body.classList.add("menu-open");
    }


    function closeSideMenu() {

        if (!sideMenu || !menuOverlay) {
            return;
        }

        sideMenu.classList.remove("open");
        menuOverlay.classList.remove("open");

        sideMenu.setAttribute("aria-hidden", "true");
        menuOverlay.setAttribute("aria-hidden", "true");

        if (menuButton) {
            menuButton.setAttribute(
                "aria-expanded",
                "false"
            );

            menuButton.setAttribute(
                "aria-label",
                "Open navigation menu"
            );
        }

        document.body.classList.remove("menu-open");

        window.setTimeout(() => {

            if (!sideMenu.classList.contains("open")) {
                sideMenu.hidden = true;
            }

            if (!menuOverlay.classList.contains("open")) {
                menuOverlay.hidden = true;
            }

        }, 400);
    }


    /* =====================================================
       MENU BUTTON
    ===================================================== */

    if (menuButton) {

        menuButton.addEventListener(
            "click",
            () => {

                const isOpen =
                    sideMenu &&
                    sideMenu.classList.contains("open");

                if (isOpen) {
                    closeSideMenu();
                } else {
                    openMenu();
                }

            }
        );
    }


    /* =====================================================
       CLOSE BUTTON
    ===================================================== */

    if (closeMenu) {

        closeMenu.addEventListener(
            "click",
            closeSideMenu
        );
    }


    /* =====================================================
       OVERLAY
    ===================================================== */

    if (menuOverlay) {

        menuOverlay.addEventListener(
            "click",
            closeSideMenu
        );
    }


    /* =====================================================
       ABOUT US — FORCE OPEN /about
    ===================================================== */

    const aboutLinks =
        document.querySelectorAll(
            'a[href="about.html"], a[href="/about"], a[href$="/about.html"]'
        );

    aboutLinks.forEach((link) => {

        link.addEventListener(
            "click",
            (event) => {

                event.preventDefault();

                closeSideMenu();

                window.location.assign("/about");
            }
        );

    });


    /* =====================================================
       SIDE MENU LINKS
    ===================================================== */

    const menuLinks =
        document.querySelectorAll(
            ".mobile-nav a, .side-navigation a"
        );

    menuLinks.forEach((link) => {

        link.addEventListener(
            "click",
            (event) => {

                const href =
                    link.getAttribute("href");

                if (!href) {
                    return;
                }

                /* ABOUT LINK IS HANDLED ABOVE */
                if (
                    href === "about.html" ||
                    href === "/about" ||
                    href.endsWith("/about.html")
                ) {
                    return;
                }

                /* INTERNAL SECTION LINK */
                if (href.startsWith("#")) {

                    event.preventDefault();

                    closeSideMenu();

                    const target =
                        document.querySelector(href);

                    if (target) {

                        window.setTimeout(() => {

                            target.scrollIntoView({
                                behavior: "smooth",
                                block: "start"
                            });

                        }, 250);

                    }

                    return;
                }

                /* NORMAL PAGE LINK */
                closeSideMenu();
            }
        );

    });


    /* =====================================================
       ESCAPE KEY
    ===================================================== */

    document.addEventListener(
        "keydown",
        (event) => {

            if (event.key === "Escape") {

                if (
                    sideMenu &&
                    sideMenu.classList.contains("open")
                ) {
                    closeSideMenu();
                }

            }

        }
    );


    /* =====================================================
       RESIZE
    ===================================================== */

    window.addEventListener(
        "resize",
        () => {

            if (
                window.innerWidth > 900 &&
                sideMenu &&
                sideMenu.classList.contains("open")
            ) {
                closeSideMenu();
            }

        }
    );


    /* =====================================================
       CONSOLE
    ===================================================== */

    console.log(
        "PKS Foundation website loaded successfully."
    );

});